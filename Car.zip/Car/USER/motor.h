#pragma once
#include "main.h"

#define Pwm_Speed 150
#define Pwm_Add 20

extern TIM_HandleTypeDef htim1;
extern UART_HandleTypeDef huart2;

void motor_init();
void pwm_move();
void move_Forward();
void move_Backward();
void move_Left();
void move_Right();
void move_Stop();
void move_Clockwise();
void move_AntiClockwise();
