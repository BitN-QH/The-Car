#include "usart.h"
#include "motor.h"
#include "encoder.h"
#include <string.h>
#include <stdio.h>

uint8_t usart2_DMA_buffer[USART_LEN];
uint8_t usart1_rx_byte = 0;
float cmd_x = 0, cmd_y = 0, cmd_z = 0;

static char rx_buf[USART_LEN + 1];
static volatile uint8_t rx_len = 0;
static volatile uint8_t rx_ready = 0;

static uint8_t up_count = 0;

void usart_rx_init(void)
{
    HAL_TIM_Base_Start_IT(&htim8);
    HAL_UART_Receive_IT(&huart1, &usart1_rx_byte, 1);
}

static void handle_command(const char *cmd)
{
    static int px = 0, py = 0, pz = 0;
    int x, y, z;

    if (sscanf(cmd, "(%d,%d,%d)", &x, &y, &z) == 3) {
        if (-10 <= x && x <= 10
            && -10 <= y && y <= 10
            && -10 <= z && z <= 10
            && (x != 0) + (y != 0) + (z != 0) <= 1)
        {
            cmd_x = x;
            cmd_y = y;
            cmd_z = z;
            if (x != px || y != py || z != pz) {
                px = x;
                py = y;
                pz = z;

                move_Stop();
                if      (x > 0) { move_Forward();      pwm_move(); }
                else if (x < 0) { move_Backward();     pwm_move(); }
                else if (y > 0) { move_Left();         pwm_move(); }
                else if (y < 0) { move_Right();        pwm_move(); }
                else if (z > 0) { move_Clockwise(); }
                else if (z < 0) { move_AntiClockwise(); }
            }
            if (x == 0 && y == 0 && z == 0) {
                move_Stop();
            }
        }
        return;
    }

    if (strcmp(cmd, "up") == 0) {
        if (up_count < 2) {
            up_count++;
        }
        return;
    }

    if (strcmp(cmd, "down") == 0) {
        up_count = 0;
        return;
    }

    if (strcmp(cmd, "stop") == 0) {
        move_Stop();
    }
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart == &huart1) {
        uint8_t ch = usart1_rx_byte;

        if (ch == '\r' || ch == '\n') {
            if (rx_len > 0) {
                rx_buf[rx_len] = '\0';
                rx_ready = 1;
            }
            rx_len = 0;
        } else if (rx_len < USART_LEN) {
            rx_buf[rx_len++] = (char)ch;
        } else {
            rx_len = 0;
        }

        HAL_UART_Receive_IT(&huart1, &usart1_rx_byte, 1);
    }
}

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
    (void)huart;
    (void)Size;
}

void usart_process_pending_command(void)
{
    if (!rx_ready) {
        return;
    }

    char cmd[USART_LEN + 1];

    __disable_irq();
    if (!rx_ready) {
        __enable_irq();
        return;
    }
    strncpy(cmd, rx_buf, sizeof(cmd));
    cmd[USART_LEN] = '\0';
    rx_ready = 0;
    __enable_irq();

    handle_command(cmd);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    static uint32_t tick = 0;

    if (htim != (&htim8)) {
        return;
    }

    encoder_update();

    if (++tick >= 50) {
        tick = 0;
        encoder_request_send();
    }
}
