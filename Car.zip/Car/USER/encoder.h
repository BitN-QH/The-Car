#pragma once
#include "main.h"

extern volatile int32_t encoder_count[4];
extern volatile int32_t encoder_speed[4];

void encoder_init(void);
void encoder_update(void);
void encoder_request_send(void);
void encoder_send_pending(UART_HandleTypeDef *huart);
void encoder_send(void);
