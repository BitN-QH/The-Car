#pragma once
#include "main.h"

#define USART_LEN 20

extern uint8_t usart2_DMA_buffer[USART_LEN];
extern uint8_t usart1_rx_byte;
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;
extern DMA_HandleTypeDef hdma_usart2_rx;
extern DMA_HandleTypeDef hdma_usart2_tx;
extern TIM_HandleTypeDef htim8;

extern float cmd_x, cmd_y, cmd_z;

void usart_rx_init(void);
void usart_process_pending_command(void);
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size);
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim);
