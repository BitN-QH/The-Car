#include "encoder.h"
#include <stdio.h>

extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;

volatile int32_t encoder_count[4] = {0};
volatile int32_t encoder_speed[4] = {0};

static volatile uint8_t encoder_send_requested = 0;
static volatile uint32_t encoder_seq = 0;
static volatile uint32_t encoder_dt_ms = 0;
static volatile int32_t encoder_snapshot_count[4] = {0};
static volatile int32_t encoder_snapshot_delta[4] = {0};

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    uint8_t b = (GPIOD->IDR >> 4) & 0x0F;

    switch (GPIO_Pin)
    {
        case GPIO_PIN_0: encoder_count[0] += (b & 0x01) ? 1 : -1; break;
        case GPIO_PIN_1: encoder_count[1] += (b & 0x02) ? 1 : -1; break;
        case GPIO_PIN_2: encoder_count[2] += (b & 0x04) ? 1 : -1; break;
        case GPIO_PIN_3: encoder_count[3] += (b & 0x08) ? 1 : -1; break;
        default: break;
    }
}

void encoder_init(void)
{
    char tx[80];
    int len = snprintf(tx, sizeof(tx), "enc_init:%ld,%ld,%ld,%ld\r\n",
                       encoder_count[0], encoder_count[1],
                       encoder_count[2], encoder_count[3]);
    HAL_UART_Transmit(&huart2, (uint8_t *)tx, len, 100);
}

void encoder_update(void)
{
    static int32_t prev[4] = {0};

    for (int i = 0; i < 4; i++)
    {
        encoder_speed[i] = encoder_count[i] - prev[i];
        prev[i] = encoder_count[i];
    }
}

void encoder_request_send(void)
{
    static uint32_t last_tick = 0;
    uint32_t now = HAL_GetTick();
    uint32_t dt = now - last_tick;

    if (dt == 0) {
        dt = 1;
    }
    last_tick = now;

    for (int i = 0; i < 4; i++)
    {
        encoder_snapshot_count[i] = encoder_count[i];
        encoder_snapshot_delta[i] = encoder_speed[i];
    }
    encoder_dt_ms = dt;
    encoder_seq++;
    encoder_send_requested = 1;
}

void encoder_send_pending(UART_HandleTypeDef *huart)
{
    if (!encoder_send_requested) {
        return;
    }

    uint32_t seq;
    uint32_t dt_ms;
    int32_t c[4];
    int32_t d[4];

    __disable_irq();
    if (!encoder_send_requested) {
        __enable_irq();
        return;
    }
    encoder_send_requested = 0;
    seq = encoder_seq;
    dt_ms = encoder_dt_ms;
    for (int i = 0; i < 4; i++) {
        c[i] = encoder_snapshot_count[i];
        d[i] = encoder_snapshot_delta[i];
    }
    __enable_irq();

    char tx[160];
    int len = snprintf(
        tx, sizeof(tx),
        "ENC,%lu,%lu,%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld\r\n",
        (unsigned long)seq, (unsigned long)dt_ms,
        (long)c[0], (long)c[1], (long)c[2], (long)c[3],
        (long)d[0], (long)d[1], (long)d[2], (long)d[3]);

    if (len > 0 && len < (int)sizeof(tx)) {
        HAL_UART_Transmit(huart, (uint8_t *)tx, (uint16_t)len, 20);
    }
}

void encoder_send(void)
{
    encoder_send_pending(&huart1);
}
