#include "motor.h"

void motor_init(){
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 0);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 0);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, 0);
}

void pwm_move(){
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, Pwm_Speed);
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, Pwm_Speed);
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_3, Pwm_Speed);
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_4, Pwm_Speed);
}

void move_Forward()
{
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, Pwm_Speed);
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, Pwm_Speed);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET);

	  HAL_UART_Transmit(&huart2, (uint8_t *)"forward\r\n", sizeof("forward\r\n")-1, 100);
}

void move_Backward()
{
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, Pwm_Speed);
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, Pwm_Speed);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET);

	  HAL_UART_Transmit(&huart2, (uint8_t *)"backward\r\n", sizeof("backward\r\n")-1, 100);
}

void move_Left()
{
	  __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, Pwm_Speed + 20);
	  __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, Pwm_Speed + 20);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET);

	  HAL_UART_Transmit(&huart2, (uint8_t *)"left\r\n", sizeof("left\r\n")-1, 100);
}

void move_Right()
{
	  __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, Pwm_Speed + 20);
	  __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, Pwm_Speed + 20);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET);

	  HAL_UART_Transmit(&huart2, (uint8_t *)"right\r\n", sizeof("right\r\n")-1, 100);
}

void move_Stop()
{
    /* PWM=0 自由滑行，不碰方向引脚 */
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 0);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 0);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, 0);

    HAL_UART_Transmit(&huart2, (uint8_t *)"stop\r\n", sizeof("stop\r\n")-1, 100);
}

void move_Clockwise()
{
//	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, Pwm_Speed);
//	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, Pwm_Speed);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET);

		__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, Pwm_Speed);
		__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, Pwm_Speed+Pwm_Add);
		__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_3, Pwm_Speed);
		__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_4, Pwm_Speed+Pwm_Add);

      HAL_UART_Transmit(&huart2, (uint8_t *)"clockwise\r\n", sizeof("clockwise\r\n")-1, 100);
}

 void move_AntiClockwise()
{
//		__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, Pwm_Speed);
//		__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, Pwm_Speed);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET);

	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET);
	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET);

		__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, Pwm_Speed+Pwm_Add);
		__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, Pwm_Speed);
		__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_3, Pwm_Speed+Pwm_Add);
		__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_4, Pwm_Speed);

    HAL_UART_Transmit(&huart2, (uint8_t *)"anticlockwise\r\n", sizeof("anticlockwise\r\n")-1, 100);
}
