################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../USER/encoder.c \
../USER/motor.c \
../USER/usart.c 

OBJS += \
./USER/encoder.o \
./USER/motor.o \
./USER/usart.o 

C_DEPS += \
./USER/encoder.d \
./USER/motor.d \
./USER/usart.d 


# Each subdirectory must supply rules for building sources it contributes
USER/%.o USER/%.su USER/%.cyclo: ../USER/%.c USER/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-USER

clean-USER:
	-$(RM) ./USER/encoder.cyclo ./USER/encoder.d ./USER/encoder.o ./USER/encoder.su ./USER/motor.cyclo ./USER/motor.d ./USER/motor.o ./USER/motor.su ./USER/usart.cyclo ./USER/usart.d ./USER/usart.o ./USER/usart.su

.PHONY: clean-USER

