# K230 CanMV MicroPython - F32C 无刷电机初始化与启动
# 串口2 TX→电机RX, 串口2 RX→电机TX, GND→GND
# 波特率 115200

from machine import UART, Pin
import time

# ── 初始化UART2 ──
# K230 标准引脚: UART2_TX=GPIO4, UART2_RX=GPIO5
uart = UART(2, baudrate=115200, bits=8, parity=0, stop=1, timeout=1000)

# ── 命令定义（地址=2） ──
def make_cmd(*data):
    """生成完整协议帧: 7A + 地址02 + 数据... + BCC + 7B"""
    frame = [0x7A, 0x02] + list(data)
    bcc = 0
    for b in frame:
        bcc ^= b
    frame += [bcc, 0x7B]
    return bytes(frame)

# 预置命令
CMD_ENABLE   = make_cmd(0x06)                # 7A 02 06 7E 7B
CMD_DISABLE  = make_cmd(0x05)                # 7A 02 05 7D 7B
CMD_MODE     = make_cmd(0x00, 0x00, 0x02)    # 单圈绝对位置模式(带轨迹)
CMD_SPEED_60 = make_cmd(0x01, 0x00, 0x3C)    # 60 RPM
CMD_ANGLE_90 = make_cmd(0x03, 0x03, 0xE8)    # 90度 (90×10=900=0x0384)

# ── 启动初始化流程 ──
def motor_init():
    print("=== F32C 电机初始化开始 ===")

    # 1. 使能电机
    print("[1/4] 使能电机...")
    uart.write(CMD_ENABLE)
    time.sleep_ms(10)

    # 2. 设置单圈绝对位置模式（带T型轨迹规划）
    print("[2/4] 设置单圈绝对位置模式...")
    uart.write(CMD_MODE)
    time.sleep_ms(10)

    # 3. 设置目标速度 60RPM
    print("[3/4] 设置速度 60RPM...")
    uart.write(CMD_SPEED_60)
    time.sleep_ms(10)

    # 4. 设置目标角度 90度 → 电机开始转动
    print("[4/4] 设置目标角度 90°...")
    uart.write(CMD_ANGLE_90)
    time.sleep_ms(10)

    print("=== F32C 电机初始化完成 ===\n")

# ── 主程序 ──
if __name__ == "__main__":
    motor_init()

    # 保持运行，防止程序退出
    while True:
        time.sleep(1)
